

// this file was present in a previus version and is supposed to be deleted now
// but asset store update delivery system doesn't allow deleting files
// so instead this file is now emptied
// feel free to delete it if you want 
